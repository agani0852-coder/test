# Fikar & Putri - Undangan Digital (Vite + React)

Cara cepat menjalankan project secara lokal:

1. Install dependencies:
   ```bash
   npm install
   ```
2. Jalankan dev server:
   ```bash
   npm run dev
   ```
3. Buka http://localhost:5173

Catatan:
- Ganti `/music.mp3` di folder `public` dengan file MP3 asli lagu "Ikat Aku di Tulang Belikatmu" (Sal Priadi).
- Jika ingin deploy ke Vercel/Netlify, hubungkan repo atau upload hasil `npm run build`.
