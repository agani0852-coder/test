import React, { useEffect, useState, useRef } from 'react'
import { motion } from 'framer-motion'

export default function App(){
  const [timeLeft, setTimeLeft] = useState({days:0,hours:0,minutes:0,seconds:0})
  const [offsetY, setOffsetY] = useState(0)
  const [guestName, setGuestName] = useState('Tamu Undangan')
  const [editing, setEditing] = useState(false)
  const [inputValue, setInputValue] = useState('')
  const audioRef = useRef(null)
  const [isPlaying, setIsPlaying] = useState(false)

  useEffect(()=>{
    const handleScroll = ()=> setOffsetY(window.scrollY)
    window.addEventListener('scroll', handleScroll)
    return ()=> window.removeEventListener('scroll', handleScroll)
  },[])

  useEffect(()=>{
    const target = new Date('2026-01-18T14:00:00').getTime()
    const iv = setInterval(()=>{
      const now = new Date().getTime()
      const dist = target - now
      if(dist<=0){ setTimeLeft({days:0,hours:0,minutes:0,seconds:0}); clearInterval(iv); return }
      const days = Math.floor(dist/(1000*60*60*24))
      const hours = Math.floor((dist%(1000*60*60*24))/(1000*60*60))
      const minutes = Math.floor((dist%(1000*60*60))/(1000*60))
      const seconds = Math.floor((dist%(1000*60))/1000)
      setTimeLeft({days,hours,minutes,seconds})
    },1000)
    return ()=> clearInterval(iv)
  },[])

  // music control - autoplay attempts after first user gesture
  useEffect(()=>{
    const tryAutoplay = ()=>{
      if(audioRef.current && !isPlaying){
        const p = audioRef.current.play()
        if(p && p.then) p.then(()=> setIsPlaying(true)).catch(()=> {})
        window.removeEventListener('click', tryAutoplay)
      }
    }
    window.addEventListener('click', tryAutoplay)
    return ()=> window.removeEventListener('click', tryAutoplay)
  },[isPlaying])

  const toggleMusic = ()=>{
    if(!audioRef.current) return
    if(isPlaying){ audioRef.current.pause(); setIsPlaying(false) }
    else{ audioRef.current.play().then(()=> setIsPlaying(true)).catch(()=>{}) }
  }

  const saveGuest = ()=>{ if(inputValue.trim()){ setGuestName(inputValue.trim()); setInputValue(''); setEditing(false) } }

  return (
    <div>
      <section className='hero'>
        <motion.h1 className='title' style={{transform:`translateY(${offsetY*0.25}px)`}} initial={{opacity:0,y:-40}} animate={{opacity:1,y:0}} transition={{duration:1}}>Fikar & Putri</motion.h1>
        <motion.p className='subtitle' style={{transform:`translateY(${offsetY*0.45}px)`}} initial={{opacity:0}} animate={{opacity:1}} transition={{delay:0.4}}>18 Januari 2026 | Gedung Dapen Bank Kalbar</motion.p>

        <div className='guest-box card' style={{marginTop:20}}>
          {editing ? (
            <div style={{display:'flex',flexDirection:'column',alignItems:'center',gap:8}}>
              <input value={inputValue} onChange={(e)=> setInputValue(e.target.value)} placeholder='Masukkan nama tamu...' style={{padding:'8px 12px',borderRadius:8,border:'1px solid #e5e7eb',width:240}} />
              <div style={{display:'flex',gap:8}}>
                <button onClick={saveGuest} style={{background:'#059669',color:'white',padding:'8px 12px',borderRadius:8,border:'none'}}>Simpan</button>
                <button onClick={()=> setEditing(false)} style={{background:'#efefef',padding:'8px 12px',borderRadius:8,border:'none'}}>Batal</button>
              </div>
            </div>
          ) : (
            <div style={{textAlign:'center'}}>
              <div style={{fontSize:14}}>Kepada Yth</div>
              <div style={{fontSize:20,fontWeight:700,marginTop:6}}>{guestName}</div>
              <button onClick={()=> setEditing(true)} style={{marginTop:8,background:'#059669',color:'white',padding:'6px 10px',borderRadius:8,border:'none'}}>Ubah Nama</button>
            </div>
          )}
        </div>
      </section>

      <div className='container'>
        <section style={{padding:'48px 0',textAlign:'center'}}>
          <h2 style={{fontSize:24,marginBottom:18}}>Countdown Menuju Acara</h2>
          <div className='countdown'>
            <div className='count-item'><motion.div key={timeLeft.days} initial={{opacity:0,y:-10}} animate={{opacity:1,y:0}} transition={{duration:0.4}} style={{fontWeight:700}}>{timeLeft.days}</motion.div><div style={{fontSize:12}}>Hari</div></div>
            <div className='count-item'><motion.div key={timeLeft.hours} initial={{opacity:0,y:-10}} animate={{opacity:1,y:0}} transition={{duration:0.4}} style={{fontWeight:700}}>{timeLeft.hours}</motion.div><div style={{fontSize:12}}>Jam</div></div>
            <div className='count-item'><motion.div key={timeLeft.minutes} initial={{opacity:0,y:-10}} animate={{opacity:1,y:0}} transition={{duration:0.4}} style={{fontWeight:700}}>{timeLeft.minutes}</motion.div><div style={{fontSize:12}}>Menit</div></div>
            <div className='count-item'><motion.div key={timeLeft.seconds} initial={{opacity:0,y:-10}} animate={{opacity:1,y:0}} transition={{duration:0.4}} style={{fontWeight:700}}>{timeLeft.seconds}</motion.div><div style={{fontSize:12}}>Detik</div></div>
          </div>
        </section>

        <section className='rsvp-section'>
          <h3 style={{fontSize:22,marginBottom:16}}>Konfirmasi Kehadiran</h3>

          <motion.div initial={{opacity:0,y:30}} whileInView={{opacity:1,y:0}} transition={{duration:0.8}} viewport={{once:true}} style={{display:'inline-block'}}>
            <button className='rsvp-button' onClick={()=> alert('Skrip RSVP: silakan hubungkan ke API/ form')}>
              RSVP Sekarang
              <div className='rsvp-shine' style={{animation:'shineMove 2s linear infinite'}}></div>
            </button>
          </motion.div>

          <div style={{marginTop:18}}>
            <button onClick={()=> toggleAudio(audioRef)} style={{padding:'8px 10px',borderRadius:8,border:'1px solid #e5e7eb'}}>Play/Pause Musik</button>
          </div>
        </section>

        <section style={{padding:'40px 0'}}>
          <h3 style={{textAlign:'center',marginBottom:16}}>Galeri</h3>
          <div className='gallery'>
            {[1,2,3,4,5,6].map(i=> <motion.img key={i} src={`/public_placeholder_img_${i}.png`} alt={'img'+i} className='img' initial={{opacity:0,y:30}} whileInView={{opacity:1,y:0}} transition={{duration:0.6,delay:i*0.12}} viewport={{once:true}} />)}
          </div>
        </section>
      </div>

      <audio ref={audioRef} src='/music.mp3' loop preload='auto' />
      <footer style={{padding:24,textAlign:'center',color:'#6b7280'}}>Template undangan — ganti music.mp3 di folder public dengan lagu Anda</footer>

      <style>{`@keyframes shineMove{0%{transform:translateX(-120%)}100%{transform:translateX(220%)}}`}</style>
    </div>
  )

  // helper for the demo play/pause button in this minimal build (kept here to avoid bundling issues)
  function toggleAudio(ref){ if(ref && ref.current){ const a = ref.current; if(a.paused){ a.play().catch(()=>{}); } else a.pause(); } }
}
